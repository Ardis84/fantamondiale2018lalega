package b.printfoot;

import javafx.scene.control.ComboBox;

public class AssegnaComitive {

		String data, giorno, luogo, ora, id;
		
		ComboBox<String> conduttore;
		
		public String getData() {
			return data;
		}
		public void setData(String data) {
			this.data = data;
		}
		public String getGiorno() {
			return giorno;
		}
		public void setGiorno(String giorno) {
			this.giorno = giorno;
		}
		public String getLuogo() {
			return luogo;
		}
		public void setLuogo(String luogo) {
			this.luogo = luogo;
		}
		public String getOra() {
			return ora;
		}
		public void setOra(String ora) {
			this.ora = ora;
		}
		public ComboBox<String> getConduttore() {
			return conduttore;
		}
		public void setConduttore(ComboBox<String> conduttore) {
			this.conduttore = conduttore;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		
		
	
}
