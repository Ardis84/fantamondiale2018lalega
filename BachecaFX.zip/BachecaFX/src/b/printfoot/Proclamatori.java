package b.printfoot;

public class Proclamatori {
	public String nome; 
	public String cognome; 
	public String datanascita; 
	public String email; 
	public String anziano; 
	public String sdm; 
	public String pregolare;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getDatanascita() {
		return datanascita;
	}
	public void setDatanascita(String datanascita) {
		this.datanascita = datanascita;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAnziano() {
		return anziano;
	}
	public void setAnziano(String anziano) {
		this.anziano = anziano;
	}
	public String getSdm() {
		return sdm;
	}
	public void setSdm(String sdm) {
		this.sdm = sdm;
	}
	public String getPregolare() {
		return pregolare;
	}
	public void setPregolare(String pregolare) {
		this.pregolare = pregolare;
	}
	
	
	
}
