package b.printfoot;


public class IncarichiElenco {
	
	String proclamatore;
	String ruolo;
	String nomina;
	String reparto;
	String id;
	String idincarico;
	String idproc;
	String validoda;
	String validoa;
	
	
	public String getProclamatore() {
		return proclamatore;
	}
	public void setProclamatore(String proclamatore) {
		this.proclamatore = proclamatore;
	}
	public String getRuolo() {
		return ruolo;
	}
	public void setRuolo(String ruolo) {
		this.ruolo = ruolo;
	}
	public String getNomina() {
		return nomina;
	}
	public void setNomina(String nomina) {
		this.nomina = nomina;
	}
	public String getReparto() {
		return reparto;
	}
	public void setReparto(String reparto) {
		this.reparto = reparto;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIdincarico() {
		return idincarico;
	}
	public void setIdincarico(String idincarico) {
		this.idincarico = idincarico;
	}
	public String getIdproc() {
		return idproc;
	}
	public void setIdproc(String idproc) {
		this.idproc = idproc;
	}
	public String getValidoda() {
		return validoda;
	}
	public void setValidoda(String validoda) {
		this.validoda = validoda;
	}
	public String getValidoa() {
		return validoa;
	}
	public void setValidoa(String validoa) {
		this.validoa = validoa;
	}
	
	


	
	
	
	
}
