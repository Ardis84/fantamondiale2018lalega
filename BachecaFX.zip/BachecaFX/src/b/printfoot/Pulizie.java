package b.printfoot;

public class Pulizie {
	
	Pulizie_Generali[] generali;
	Pulizie_Settimanali[] settimanali;
	
	
	public Pulizie_Generali[] getGenerali() {
		return generali;
	}
	public void setGenerali(Pulizie_Generali[] generali) {
		this.generali = generali;
	}
	public Pulizie_Settimanali[] getSettimanali() {
		return settimanali;
	}
	public void setSettimanali(Pulizie_Settimanali[] settimanali) {
		this.settimanali = settimanali;
	}

	
	
}
