package b.actions.proclamatori;

import javafx.stage.Stage;

public class Aggiungi {

	
	public static void view(Stage primaryStage) {
		System.out.println("ok");
	}
}
