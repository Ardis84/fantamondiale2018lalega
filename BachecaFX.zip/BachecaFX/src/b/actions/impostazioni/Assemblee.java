package b.actions.impostazioni;

public class Assemblee {

}
